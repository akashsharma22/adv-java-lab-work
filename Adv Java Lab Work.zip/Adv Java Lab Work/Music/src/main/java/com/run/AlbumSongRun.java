package com.run;

import java.time.LocalDate;

import com.dao.GenericDao;
import com.entity.Album;
import com.entity.Song;

import java.util.List;

public class AlbumSongRun {

	public static void main(String[] args) {
		GenericDao dao = new GenericDao();
		
		Album album = new Album();
		album.setName("Himesh hits");
		album.setReleaseDate(LocalDate.of(2008, 12, 21));
		album.setCopyright("Hashmi Music");
		dao.save(album);
		/*
		Album album1 = (Album)dao.fetchById(Album.class, 1);
		Song song = new Song();
		song.setTitle("Aap ka Suroor");
		song.setArtist("Himesh Bhai");
		song.setDuration(4.35);
		song.setAlbum(album1);
		dao.save(song);
		*/
		List<Song> songs = dao.fetchSongsSungBy("Himesh Bhai");
		for(Song song : songs )
			System.out.println(song.getTitle() + " " + song.getDuration());
 
			dao.delete(Song.class, 8);
	}

}
