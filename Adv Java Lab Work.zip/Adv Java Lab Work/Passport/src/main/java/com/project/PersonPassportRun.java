package com.project;

import java.time.LocalDate;

public class PersonPassportRun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonPassportDao dao = new PersonPassportDao();
		
		Person1 p1 = new Person1();
		p1.setName("Akash");
		p1.setEmail("akash123@gmail.com");
		p1.setDateOfBirth(LocalDate.of(1996, 1,1));
		
		Passport1 ps = new Passport1();
		ps.setIssueDate(LocalDate.of(2021, 11, 11));
		ps.setExpiryDate(LocalDate.of(2030, 11, 11));
		ps.setIssuedBy("Govt. of India");
		
		p1.setPassport1(ps);
		ps.setPerson1(p1);
		
		dao.add(p1);
	}

}
