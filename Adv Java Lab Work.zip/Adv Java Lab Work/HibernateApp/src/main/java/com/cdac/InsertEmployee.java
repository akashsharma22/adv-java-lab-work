package com.cdac;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class InsertEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Employee emp = new Employee();
		emp.setEmpno(101);
		emp.setName("Shende");
		emp.setSalary(11100);
		emp.setDateOfJoin(LocalDate.of(2022,10,11));
		
		em.persist(emp);
		
		tx.commit();
		emf.close();
		
	}

}
