package pack2;

public class LoginService {
	public boolean loginCheck(String username, String password) {
		if(username.equals("akash") && password.equals("123"))
			return true;
		return false;
	}
}
