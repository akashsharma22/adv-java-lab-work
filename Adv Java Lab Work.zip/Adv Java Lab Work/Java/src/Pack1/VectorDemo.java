package Pack1;
import java.util.Collections;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		Vector<Integer> list = new Vector<>();
		list.add(50);
		list.add(10);
		list.add(20);
		list.add(40);
		list.add(60);
		
		//System.out.println(list);// TODO Auto-generated method stub
		System.out.println(list.size());
		Collections.sort(list);
		System.out.println(list);
		
		System.out.println(list.capacity());
		list.remove(1);
		System.out.println(list);
		
	}

}
