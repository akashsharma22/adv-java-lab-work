package com.cdac.component;

import org.springframework.stereotype.Component;

@Component
public class AxisBank implements Bank {

	public void withdraw(int atmId, int acno, double amount) {
		// TODO Auto-generated method stub
		System.out.println("Customer of AxisBank wants to withdarw money from his account..");
	}

		
}
