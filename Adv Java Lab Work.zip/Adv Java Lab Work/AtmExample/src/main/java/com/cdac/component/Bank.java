package com.cdac.component;

public interface Bank {
	public void withdraw(int atmId, int acno, double amount);
}
