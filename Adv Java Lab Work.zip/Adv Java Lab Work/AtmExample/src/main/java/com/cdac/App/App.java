package com.cdac.App;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.component.Atm;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new ClassPathXmlApplicationContext("my_spring_config.xml");
		
		Atm atm = (Atm) ctx.getBean("hdfcAtm");
		atm.withdraw(11111, 5000);
	}

}
